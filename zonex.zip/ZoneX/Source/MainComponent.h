#ifndef MAINCOMPONENT_H_INCLUDED
#define MAINCOMPONENT_H_INCLUDED

#include "../JuceLibraryCode/JuceHeader.h"
#include "radial_eq.h"
class MainContentComponent   : public  Timer, KeyListener, public Component, Button::Listener

    

{
    
public:
    
    bool playing = false;
    bool playingV = false;
    bool setting = false;
    std::unique_ptr<HyperlinkButton> hyperlinkButton;
    double sampleRate;
    int audioBufferSize;
    bool back = false;
    int level = 0;
    int metaLevel = 0;
    std::unique_ptr<Radial_eq> radial_eq;
    bool loadNewTip = true;
   //
    TextButton playButton;
    TextButton visualizerButton;
    bool hasRun = false;
    String tips [5] ={"A soothing tongue is a tree of life...\nProverbs 15:4a\nThe Holy Bible",
        "Fact: The twelve hours of the clock are the twelve notes of the piano in Zone:X.",
        "Fact: The trail indicates pitch, whereas the radial frets indicate frequencies.",
        "Fact: The loopy lines around the sonic starship are a polar graph of the sound's wave.",

    };

    bool     keyStateChanged (bool isKeyDown, Component *originatingComponent) override
    {
        return true;
    }
    
    bool keyPressed (const KeyPress &key, Component *originatingComponent) override
    {
        if(key == KeyPress::escapeKey)
        {
           if (radial_eq!=nullptr) off();
           else JUCEApplication::getInstance()->quit();

        }
        return true;
    }
                                          std::unique_ptr<AudioDeviceManager> audiodevicemanager = nullptr;
AudioIODevice *device;
    MainContentComponent()
    {
        setBounds (0, 0, getWidth(), getHeight());
        addAndMakeVisible (playButton);
        playButton.setButtonText ("Game");
        addAndMakeVisible (visualizerButton);
        visualizerButton.setButtonText ("Visualizer");
        playButton.addListener (this);      
        visualizerButton.addListener (this);
        hyperlinkButton.reset (new HyperlinkButton ("Donate", URL ("https://www.givinggrid.com/zonex/")));
        addAndMakeVisible (hyperlinkButton.get());
        hyperlinkButton->setTooltip (TRANS("There's a lot going on in Zone:X, find out about it here!"));
        hyperlinkButton->setFont 	( 	25,	false	) 		;
        
           RuntimePermissions::request (RuntimePermissions::recordAudio,
                                     [this] (bool wasGranted)
        {
                                     if (!wasGranted)             JUCEApplication::getInstance()->systemRequestedQuit();
                                     else{
                                         audiodevicemanager.reset(new AudioDeviceManager);
                                         device = audiodevicemanager->getCurrentAudioDevice ();
                                         auto numOutputChannels = device != nullptr ? device->getActiveOutputChannels().countNumberOfSetBits() : 2;
                                         audiodevicemanager->initialiseWithDefaultDevices(1,numOutputChannels);
                                          AudioDeviceManager::AudioDeviceSetup audioDeviceSetup;
                                        audiodevicemanager->getAudioDeviceSetup(audioDeviceSetup);
                                         AudioIODevice* currentAudioIODevice = audiodevicemanager->getCurrentAudioDevice();
                                         Array<double> sampleRates = currentAudioIODevice->getAvailableSampleRates();
                                         Array<int> bufferSizes = currentAudioIODevice->getAvailableBufferSizes();
                                         int mediumBuffer = bufferSizes[0];
                                         for(int n = 0; n<bufferSizes.size();n++) if(bufferSizes[n]<1500)
                                            mediumBuffer = bufferSizes[n];
                                            double mediumSample = sampleRates[0];
                                         for(int n = 0; n<sampleRates.size();n++) if(sampleRates[n]<42000)
                                            mediumSample = sampleRates[n];
                                         audioDeviceSetup.bufferSize = mediumBuffer;
                                         audioDeviceSetup.sampleRate= mediumSample;
                                         
                                         sampleRate = audioDeviceSetup.sampleRate;
                                         audioBufferSize = audioDeviceSetup.bufferSize;

                                     }
                                     });
        setWantsKeyboardFocus(true);
        addKeyListener(this);
         Rectangle<int> r = Desktop::getInstance().getDisplays().getPrimaryDisplay()->userArea;
#if defined JUCE_IOS or JUCE_ANDROID
       
        int x = r.getWidth();
        int y = r.getHeight();
#else
        
        int x = r.getWidth()/2.;
        int y = r.getHeight()/2.;
#endif
        setSize (x, y);
        this->setVisible(true);
        
        Timer::startTimer(1000/60.);
    }

    ~MainContentComponent()
    {

        if ( radial_eq!=nullptr)off();
        audiodevicemanager = nullptr;
        hyperlinkButton = nullptr;
    }

    void off()
    {  
        loadNewTip = true;
        menuJustOpened = true;
        repaint();
        Desktop::setScreenSaverEnabled(true);


        getTopLevelComponent()->setBounds (0, 0, getWidth(), getHeight());
        resized();
        playButton.setVisible(true);
        visualizerButton.setVisible(true);
        hyperlinkButton->setVisible(true);
        if (radial_eq != nullptr)
            {
                if (radial_eq->level>0 and !playingV)
                {
                    level = radial_eq->level-1;
                    metaLevel = radial_eq->metaLevel;
                }

                 audiodevicemanager->removeAudioCallback (radial_eq->audiosourceplayer1.get());
                audiodevicemanager->getCurrentAudioDevice ()->stop();
                radial_eq->releaseResources ();
            }
            radial_eq=nullptr;
            playing = false;
            playingV = false;
            back = false;
    }
    bool menuJustOpened = true;
    void timerCallback() override
    {


        if (radial_eq!=nullptr) if (radial_eq->back) back = true;
        if (back)
        {   
            off();
        }
        if (playing)
        {
            if(radial_eq == nullptr)
            {

                playButton.setVisible(false);
                visualizerButton.setVisible(false);
                hyperlinkButton->setVisible(false);
                hasRun = false;
                Desktop::setScreenSaverEnabled(false);
                radial_eq.reset(new Radial_eq());

                radial_eq->sampleRate=sampleRate;
                radial_eq->audioBufferSize = audioBufferSize;
                radial_eq->level =level;
                radial_eq->metaLevel =metaLevel;
                radial_eq->setSourceWrapper();

                                audiodevicemanager->getCurrentAudioDevice ()->start(radial_eq->audiosourceplayer1.get());
                addAndMakeVisible(radial_eq.get());

            }
            else
            {
                radial_eq->setBounds (0, 0, getWidth(), getHeight());
                radial_eq->engineNoiseOn = false;
                radial_eq->openGLOn = true;
                radial_eq->pulsingColorsOn = true;
                radial_eq->setVisible(true);
                if (!playingV) radial_eq->playingV = false;
                else radial_eq->playingV = true;
            }
        }
        repaint();

    }
int whichTip = 0;
    uint32 lastTime = Time::getApproximateMillisecondCounter();
    void paint (Graphics& g) override
    {
                    g.setFont(18);
        g.fillAll(Colours::beige);
        if (           lastTime+ 30000 < Time::getApproximateMillisecondCounter() )
        {
             lastTime = Time::getApproximateMillisecondCounter();

            loadNewTip = false;
             whichTip = Time::currentTimeMillis()%5;

             }
                             g.drawMultiLineText     (tips[whichTip],getWidth()*3.f/30.f, getHeight()/5*4.f, getWidth()*24.f/30.f)     ;

           // if (playing) g.fillAll(Colours::grey);
    }
    void resized() override
    {
        setBounds (0, 0, getWidth(), getHeight());

        float width = float(getWidth());
        float height = float(getHeight());
        visualizerButton.setBounds (width*8.5f/30.f, height*2.f/30.f, width*13.f/30.f,height*8.f/30.f);
        playButton.setBounds (width*8.5f/30.f,height*10.f/30.f, width*13.f/30.f, height*8.f/30.f);
        hyperlinkButton->setBounds (width*8.5f/30.f, height*17.f/30.f, width*13.f/30.f, height*8.f/30.f);
        setBounds (0, 0, getWidth(), getHeight());
        if (radial_eq != 0)radial_eq->setBounds (0, 0, getWidth(), getHeight());
    }
    
       void buttonClicked (Button* button) override
    {
        if (button == &playButton)
        {
            playing = true;
            startTimer(1);
        }
        else if (button == &visualizerButton)
        {
            playing = true;
            playingV = true;
            startTimer(1);
        }
               
    }
     
private:
    //==============================================================================
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainContentComponent)
};


#endif  // MAINCOMPONENT_H_INCLUDED
